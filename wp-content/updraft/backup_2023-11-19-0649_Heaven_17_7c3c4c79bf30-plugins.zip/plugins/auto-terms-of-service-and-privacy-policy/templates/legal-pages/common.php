<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<input type="hidden" name="post_title" data-wpautoterms="" value="placeholder"/>
