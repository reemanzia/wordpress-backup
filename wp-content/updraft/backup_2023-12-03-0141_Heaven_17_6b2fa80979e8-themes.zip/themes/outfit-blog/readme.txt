=== Outfit Blog ===

Contributors: crimsonthemes
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, one-column, two-columns, custom-header, blog, entertainment, portfolio
Requires at least: 5.1
Requires PHP: 5.6
Tested up to: 6.2
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Outfit Blog is a clean and minimal blog theme.. If you want to start the blog and need a theme that has it all, search no more. The perfect destination for every professional  Food Delivery Service, Fast Food, travel blogger and traveler is here! Outfit Blog was designed for all modern adventure traveller, all types of delivery, who need to create personal blog site , travel blogger with simple and creative features and effects to make readers feel the pleasure of reading blog posts and articles. If you are a blogger and traveller, then it’s a perfect choice for you if you don’t need to have any experiment to setup your Wordpress personal blog, it’s super simple and easy to setup, you will get high quality, responsive, well crafted blog out of the box to make writers only focuses on writing content, and it has great typography to make your fans and followers focus on every word you write. Get Outfit Blog today and share your stories with complete ease!

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright ==

Outfit Blog WordPress Theme, Copyright 2023 Crimson Themes
Outfit Blog is distributed under the terms of the GNU GPL

== Changelog ==

= 1.0.2 = 
* Initial release

== Theme Screenshot ==

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/927054

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1048486

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1007879

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1418586

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1607159

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/785294

== Resources ==

Font Awesome
License: MIT
Source: https://fontawesome.com

normalize.css, Copyright 2012-2016 Nicolas Gallagher and Jonathan Neal
License: MIT
Source: https://necolas.github.io/normalize.css/

Underscores, Copyright 2012-2017 Automattic
License: GPLv2 or later
Source: https://www.gnu.org/licenses/gpl-2.0.html